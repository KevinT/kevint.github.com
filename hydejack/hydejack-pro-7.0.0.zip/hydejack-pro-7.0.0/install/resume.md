---
layout: resume
title: Résumé*
description: >
  This is the description of your resume page as it will be shown on search engines.
  Open `resume.md` to edit this text.
  You can hide it (only visible to search engines) by setting `no_description` to `true`.
no_description: false
menu: true
order: 3
rel: me
---
