---
title: Blog
description: >
  The official Hydejack blog. Version updates, example content and how-to guides on how to blog with Jekyll.
image: /assets/img/projects/default.jpg
menu: true
order: 1
---
