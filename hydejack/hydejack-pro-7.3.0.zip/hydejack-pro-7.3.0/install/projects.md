---
layout: projects
title: Projects
show_collection: projects
description: >
  This is a demo of the `projects` layout, which is included in the PRO version of Hydejack.
  Here it is used to showcase different customizations of Hydejack.
  Open `projects.md` to edit this text.
menu: true
order: 2
---
