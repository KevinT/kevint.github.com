---
layout: resume
title: Résumé*
description: >
  This is the `description` of your resume page, as it will be seen by search engines.
  You can hide this box by setting `hide_description` to `true` in the front matter.
  Open `resume.md` to edit this text.
hide_description: false
menu: true
order: 3
rel: me
---
